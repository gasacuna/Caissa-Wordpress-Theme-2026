<?php
/**
 * GENERADO por el builder: las @font-face autohospedadas.
 *
 * Salen del HTML del repo, que ya trae las fuentes (fonts/*.woff2). Lo unico que se
 * reescribe son las URLs: el repo apunta a /fonts/ (raiz del dominio) y en el tema
 * viven en assets/fonts/.
 *
 * Van INLINE y no como archivo: pesan 1,3 KB, asi que una peticion aparte costaria
 * mas que el ahorro. Se precarga solo plus-jakarta-sans-v12-latin.woff2, que es el
 * texto de la pagina; las demas entran con font-display:swap cuando llegan.
 *
 * Plus Jakarta Sans es una fuente VARIABLE: un archivo cubre todos los pesos.
 *
 * @package Caissa
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function caissa_fuentes_inline() {
	?>
<link rel="preload" href="<?php echo esc_url( CAISSA_URI . '/assets/fonts/plus-jakarta-sans-v12-latin.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
<style id="caissa-fuentes">@font-face{font-family:'Plus Jakarta Sans';font-style:normal;font-weight:200 800;font-display:swap;src:url(<?php echo esc_url( CAISSA_URI . '/assets/fonts/plus-jakarta-sans-v12-latin.woff2' ); ?>) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Plus Jakarta Sans';font-style:normal;font-weight:200 800;font-display:swap;src:url(<?php echo esc_url( CAISSA_URI . '/assets/fonts/plus-jakarta-sans-v12-latin-ext.woff2' ); ?>) format('woff2');unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Caveat';font-style:normal;font-weight:700;font-display:swap;src:url(<?php echo esc_url( CAISSA_URI . '/assets/fonts/caveat-v23-700-latin.woff2' ); ?>) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Caveat';font-style:normal;font-weight:700;font-display:swap;src:url(<?php echo esc_url( CAISSA_URI . '/assets/fonts/caveat-v23-700-latin-ext.woff2' ); ?>) format('woff2');unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}</style>
	<?php
}
